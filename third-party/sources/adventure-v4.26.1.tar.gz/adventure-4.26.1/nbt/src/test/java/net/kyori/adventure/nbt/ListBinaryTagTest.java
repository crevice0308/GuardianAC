/*
 * This file is part of adventure, licensed under the MIT License.
 *
 * Copyright (c) 2017-2025 KyoriPowered
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package net.kyori.adventure.nbt;

import com.google.common.collect.ImmutableList;
import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.Test;

import static net.kyori.adventure.nbt.LongBinaryTag.longBinaryTag;
import static net.kyori.adventure.nbt.StringBinaryTag.stringBinaryTag;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ListBinaryTagTest {
  @Test
  void testCreateEndBuilder() {
    assertThrows(IllegalArgumentException.class, () -> ListBinaryTag.builder(BinaryTagTypes.END));
  }

  @Test
  void testAddEnd() {
    final ListBinaryTag l0 = ListBinaryTag.empty();
    assertThrows(IllegalArgumentException.class, () -> l0.add(EndBinaryTag.endBinaryTag()));
  }

  @Test
  void testAddOtherToEndChangesType() {
    final ListBinaryTag l0 = ListBinaryTag.empty();
    final ListBinaryTag l1 = l0.add(IntBinaryTag.intBinaryTag(13));
    assertEquals(BinaryTagTypes.INT, l1.elementType());
  }

  @Test
  void testMismatchedAdd() {
    final ListBinaryTag l0 = ListBinaryTag.listBinaryTag(BinaryTagTypes.BYTE, ImmutableList.of(ByteBinaryTag.byteBinaryTag((byte) 0)));
    assertThrows(IllegalArgumentException.class, () -> l0.add(IntBinaryTag.intBinaryTag(1)));
  }

  @Test
  void testSet() {
    final IntBinaryTag i0 = IntBinaryTag.intBinaryTag(0);
    final IntBinaryTag i1 = IntBinaryTag.intBinaryTag(1);
    final IntBinaryTag i2 = IntBinaryTag.intBinaryTag(2);
    final ListBinaryTag l3 = ListBinaryTag.listBinaryTag(BinaryTagTypes.INT, ImmutableList.of(i0, i1, i2));
    final ListBinaryTag l2 = l3.set(1, i0, removed -> assertEquals(i1, removed));
    assertEquals(i0, l2.get(0));
    assertEquals(i0, l2.get(1));
    assertEquals(i2, l2.get(2));
    final ListBinaryTag l1 = l2.set(2, i0, null);
    assertEquals(i0, l1.get(0));
    assertEquals(i0, l1.get(1));
    assertEquals(i0, l1.get(2));

    // ensure original is untouched
    assertEquals(i0, l3.get(0));
    assertEquals(i1, l3.get(1));
    assertEquals(i2, l3.get(2));
  }

  @Test
  void testRemove() {
    final IntBinaryTag i0 = IntBinaryTag.intBinaryTag(0);
    final IntBinaryTag i1 = IntBinaryTag.intBinaryTag(1);
    final IntBinaryTag i2 = IntBinaryTag.intBinaryTag(2);
    final ListBinaryTag l3 = ListBinaryTag.listBinaryTag(BinaryTagTypes.INT, ImmutableList.of(i0, i1, i2));
    final ListBinaryTag l2 = l3.remove(1, removed -> assertEquals(i1, removed));
    assertEquals(2, l2.size());
    assertEquals(i0, l2.get(0));
    assertEquals(i2, l2.get(1));
    final ListBinaryTag l1 = l2.remove(0, null);
    assertEquals(1, l1.size());
    assertEquals(i2, l1.get(0));

    // ensure original is untouched
    assertEquals(i0, l3.get(0));
    assertEquals(i1, l3.get(1));
    assertEquals(i2, l3.get(2));
  }

  @Test
  void testCreateHeterogeneous() {
    final IntBinaryTag first = IntBinaryTag.intBinaryTag(4);
    final StringBinaryTag second = stringBinaryTag("hello");
    final ListBinaryTag heteroTag = ListBinaryTag.heterogeneousListBinaryTag()
      .add(first)
      .add(second)
      .build();

    assertEquals(first, heteroTag.get(0));
    assertEquals(second, heteroTag.get(1));
  }

  @Test
  void testBoxHeterogeneous() {
    final ListBinaryTag input = ListBinaryTag.listBinaryTag(
      BinaryTagTypes.LIST_WILDCARD,
      Arrays.asList(longBinaryTag(5), stringBinaryTag("five"))
    );
    final ListBinaryTag expected = ListBinaryTag.builder()
      .add(CompoundBinaryTag.from(Collections.singletonMap("", longBinaryTag(5))))
      .add(CompoundBinaryTag.from(Collections.singletonMap("", stringBinaryTag("five"))))
      .build();

    assertEquals(expected, input.wrapHeterogeneity());
  }

  @Test
  void testBoxHeterogeneousDoubleWrap() {
    // For backwards compatibility, wrapping a tag which is already {"": value} should wrap it again.
    final ListBinaryTag input = ListBinaryTag.listBinaryTag(
      BinaryTagTypes.LIST_WILDCARD,
      Arrays.asList(
        CompoundBinaryTag.from(Collections.singletonMap("", longBinaryTag(5))),
              StringBinaryTag.stringBinaryTag("five")
      )
    );
    final ListBinaryTag expected = ListBinaryTag.builder()
      .add(CompoundBinaryTag.from(Collections.singletonMap("", CompoundBinaryTag.from(Collections.singletonMap("", longBinaryTag(5))))))
      .add(CompoundBinaryTag.from(Collections.singletonMap("", stringBinaryTag("five"))))
      .build();

    assertEquals(expected, input.wrapHeterogeneity());
  }

  @Test
  void testBoxingReversible() {
    final ListBinaryTag input = ListBinaryTag.listBinaryTag(
      BinaryTagTypes.LIST_WILDCARD,
      Arrays.asList(longBinaryTag(5), stringBinaryTag("five"))
    );
    assertEquals(input, input.wrapHeterogeneity().unwrapHeterogeneity());
  }
}
