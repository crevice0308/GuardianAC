/*
 * This file is part of adventure, licensed under the MIT License.
 *
 * Copyright (c) 2017-2025 KyoriPowered
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package net.kyori.adventure.extra.kotlin

import net.kyori.adventure.text.Component
import net.kyori.adventure.text.ComponentLike
import net.kyori.adventure.text.JoinConfiguration

/**
 * Adds [that] as a child component.
 *
 * @return a component
 * @since 4.6.0
 */
public operator fun Component.plus(that: ComponentLike): Component = this.append(that)

/**
 * Joins this array of components using the provided [config].
 *
 * @param config the join configuration
 * @return the resulting component
 * @since 4.10.0
 */
public fun Array<out ComponentLike>.join(config: JoinConfiguration = JoinConfiguration.noSeparators()): Component =
    this.toList().join(config)

/**
 * Joins this iterable of components using the provided [config].
 *
 * @param config the join configuration
 * @return the resulting component
 * @since 4.10.0
 */
public fun Iterable<ComponentLike>.join(config: JoinConfiguration = JoinConfiguration.noSeparators()): Component =
    Component.join(config, this)
